#include "../include/BalanceController.h"
#include <cstdio>

int main() {
    using namespace rd;
    Skeleton sk = CreateHumanoidSkeleton(75.f);

    // Tüm kemikleri makul bir world pozisyonuna yerleştirelim (ayakta duran karakter)
    for (auto& bone : sk.Bones()) {
        bone.physWorldPos = Vec3(0.f, 1.0f, 0.f); // basitleştirilmiş, hepsi gövde etrafında
    }
    // Ayakları gerçekçi konuma koy
    sk.GetBone(sk.FindByType(BoneType::FootL)).physWorldPos = Vec3(-0.15f, 0.f, 0.f);
    sk.GetBone(sk.FindByType(BoneType::FootR)).physWorldPos = Vec3(0.15f, 0.f, 0.f);

    Vec3 com = BalanceController::ComputeCenterOfMass(sk);
    printf("COM: (%.3f, %.3f, %.3f)\n", com.x, com.y, com.z);

    SupportPolygon support;
    support.footL_ground = Vec3(-0.15f, 0.f, 0.f);
    support.footR_ground = Vec3(0.15f, 0.f, 0.f);
    support.footLGrounded = true;
    support.footRGrounded = true;

    BalanceController bc(0.35f);

    // Senaryo 1: Karakter dengede (COM merkezde)
    BalanceState s1 = bc.Evaluate(sk, support, com, 1.f / 60.f);
    printf("[Dengede] inside=%d instability=%.3f\n", s1.supportResult.inside, s1.instabilityRatio);

    // Senaryo 2: Karaktere itme uygula (COM'u X ekseninde kaydır)
    for (auto& bone : sk.Bones()) {
        bone.physWorldPos.x += 0.5f; // sağa doğru ittirildi
    }
    Vec3 com2 = BalanceController::ComputeCenterOfMass(sk);
    BalanceState s2 = bc.Evaluate(sk, support, com, 1.f/60.f); // prevCOM eski com
    printf("[Itildi]  inside=%d instability=%.3f distOutside=%.3f\n",
           s2.supportResult.inside, s2.instabilityRatio, s2.supportResult.distanceOutside);

    Quat recovery = bc.ComputeHipRecoveryRotation(s2);
    Vec3 err = recovery.ToAngularError();
    printf("Recovery lean axis*angle: (%.3f, %.3f, %.3f) |%.3f rad|\n",
           err.x, err.y, err.z, err.Length());

    // Senaryo 3: Çok fazla itildi (recovery imkansız)
    for (auto& bone : sk.Bones()) {
        bone.physWorldPos.x += 2.0f; // çok büyük itme
    }
    BalanceState s3 = bc.Evaluate(sk, support, com2, 1.f/60.f);
    printf("[Cok itildi] inside=%d instability=%.3f isCritical=%d\n",
           s3.supportResult.inside, s3.instabilityRatio, s3.isBalanceCritical);

    return 0;
}
