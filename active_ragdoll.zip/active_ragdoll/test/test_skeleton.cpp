#include "../include/Skeleton.h"
#include <cstdio>
int main() {
    rd::Skeleton sk = rd::CreateHumanoidSkeleton(75.f);
    printf("Bone count: %zu\n", sk.BoneCount());
    printf("Total mass: %.2f kg\n", sk.TotalMass());
    auto pelvis = sk.FindByType(rd::BoneType::Pelvis);
    printf("Pelvis index: %d, mass: %.2f kg\n", pelvis, sk.GetBone(pelvis).inertial.mass);
    return 0;
}
