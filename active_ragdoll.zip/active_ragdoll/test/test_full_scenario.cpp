#include "../include/ActiveRagdollSystem.h"
#include <cstdio>

using namespace rd;

const char* StateName(RagdollState s) {
    switch (s) {
        case RagdollState::Animated: return "ANIMATED";
        case RagdollState::RagdollReacting: return "RAGDOLL_REACTING";
        case RagdollState::Recovering: return "RECOVERING";
        case RagdollState::Falling: return "FALLING";
    }
    return "?";
}

void RunScenario(const char* name, float impulseStrength) {
    printf("\n=== Senaryo: %s (impulse=%.1f) ===\n", name, impulseStrength);

    Skeleton sk = CreateHumanoidSkeleton(75.f);

    // Başlangıç pozisyonları: ayakta duran bir karakter (basitleştirilmiş world pose)
    for (auto& bone : sk.Bones()) bone.physWorldPos = Vec3(0.f, 1.f, 0.f);
    sk.GetBone(sk.FindByType(BoneType::Pelvis)).physWorldPos = Vec3(0.f, 1.0f, 0.f);
    sk.GetBone(sk.FindByType(BoneType::FootL)).physWorldPos = Vec3(-0.15f, 0.f, 0.f);
    sk.GetBone(sk.FindByType(BoneType::FootR)).physWorldPos = Vec3(0.15f, 0.f, 0.f);

    ActiveRagdollSystem sys(sk);

    SupportPolygon support;
    support.footL_ground = Vec3(-0.15f, 0.f, 0.f);
    support.footR_ground = Vec3(0.15f, 0.f, 0.f);
    support.footLGrounded = true;
    support.footRGrounded = true;

    // Darbeyi uygula (örnek: bir araç çarpması veya yumruk)
    sys.ApplyImpulse(Vec3(impulseStrength, 0.f, 0.f));
    printf("t=0.00s  state=%-18s (darbe sonrasi)\n", StateName(sys.State()));

    const float dt = 1.f / 60.f;
    RagdollState lastState = sys.State();

    for (int frame = 1; frame <= 240; ++frame) { // 4 saniye simülasyon
        sys.Update(dt, support);

        if (sys.State() != lastState) {
            printf("t=%.2fs  state degisti: %s -> %s  (instability=%.2f)\n",
                   frame * dt, StateName(lastState), StateName(sys.State()),
                   sys.LastBalanceState().instabilityRatio);
            lastState = sys.State();
        }
    }

    printf("Sonuc (4s sonra): %s\n", StateName(sys.State()));
}

int main() {
    // Hafif darbe: dengeyi az bozar, toparlanması beklenir
    RunScenario("Hafif darbe", 60.f);

    // Orta darbe: belirgin sallanma ama muhtemelen toparlanır
    RunScenario("Orta darbe", 150.f);

    // Çok güçlü darbe: dengeyi tamamen bozar, düşmesi beklenir
    RunScenario("Cok guclu darbe (arac carpmasi)", 800.f);

    return 0;
}
