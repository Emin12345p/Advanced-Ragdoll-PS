#pragma once
// =============================================================================
// RagdollMath.h
//
// NOT: Bu dosya SADECE bu sistemi standalone derleyip test edebilmek icin var.
// ForgeEngine'e entegre ederken bu tipleri SIL ve kendi Vec3/Quat/Mat4
// tiplerini kullan. Asagidaki arayuz (metod isimleri, semantik) senin mevcut
// math kutuphanenle ayni sekilde calismali; sadece implementasyonu degistir.
// =============================================================================

#include <cmath>
#include <algorithm>

namespace rd {

struct Vec3 {
    float x = 0.f, y = 0.f, z = 0.f;

    Vec3() = default;
    Vec3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}

    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    Vec3 operator-() const { return {-x, -y, -z}; }
    Vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
    Vec3& operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
    Vec3& operator-=(const Vec3& o) { x -= o.x; y -= o.y; z -= o.z; return *this; }
    Vec3& operator*=(float s) { x *= s; y *= s; z *= s; return *this; }

    float Dot(const Vec3& o) const { return x * o.x + y * o.y + z * o.z; }
    Vec3 Cross(const Vec3& o) const {
        return { y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x };
    }
    float LengthSq() const { return Dot(*this); }
    float Length() const { return std::sqrt(LengthSq()); }

    Vec3 Normalized() const {
        float len = Length();
        if (len < 1e-8f) return {0.f, 0.f, 0.f};
        return *this * (1.f / len);
    }

    static Vec3 Zero() { return {0.f, 0.f, 0.f}; }
    static Vec3 Up()   { return {0.f, 1.f, 0.f}; }
};

inline Vec3 operator*(float s, const Vec3& v) { return v * s; }

// Quaternion: (x, y, z, w) - Hamilton convention, w = scalar
struct Quat {
    float x = 0.f, y = 0.f, z = 0.f, w = 1.f;

    Quat() = default;
    Quat(float x_, float y_, float z_, float w_) : x(x_), y(y_), z(z_), w(w_) {}

    static Quat Identity() { return {0.f, 0.f, 0.f, 1.f}; }

    static Quat FromAxisAngle(const Vec3& axis, float angleRad) {
        Vec3 n = axis.Normalized();
        float half = angleRad * 0.5f;
        float s = std::sin(half);
        return { n.x * s, n.y * s, n.z * s, std::cos(half) };
    }

    Quat Conjugate() const { return {-x, -y, -z, w}; }

    Quat operator*(const Quat& o) const {
        // this * o  (apply o first, then this — standard Hamilton product)
        return {
            w * o.x + x * o.w + y * o.z - z * o.y,
            w * o.y - x * o.z + y * o.w + z * o.x,
            w * o.z + x * o.y - y * o.x + z * o.w,
            w * o.w - x * o.x - y * o.y - z * o.z
        };
    }

    Vec3 Rotate(const Vec3& v) const {
        // v' = q * v * q^-1, optimized form
        Vec3 qv{x, y, z};
        Vec3 t = qv.Cross(v) * 2.f;
        return v + t * w + qv.Cross(t);
    }

    float Length() const { return std::sqrt(x*x + y*y + z*z + w*w); }

    Quat Normalized() const {
        float len = Length();
        if (len < 1e-8f) return Identity();
        float inv = 1.f / len;
        return {x * inv, y * inv, z * inv, w * inv};
    }

    // Donduren acinin (axis-angle) "error vector" olarak cikarilmasi.
    // PD controller'da hata terimi olarak kullanilir: axis * angle
    Vec3 ToAngularError() const {
        Quat q = Normalized();
        // w negatifse, en kisa yoldan donmek icin isareti cevir
        if (q.w < 0.f) { q.x = -q.x; q.y = -q.y; q.z = -q.z; q.w = -q.w; }
        float sinHalfAngle = std::sqrt(q.x*q.x + q.y*q.y + q.z*q.z);
        if (sinHalfAngle < 1e-6f) return Vec3::Zero();
        float angle = 2.f * std::atan2(sinHalfAngle, q.w);
        float invSin = 1.f / sinHalfAngle;
        return Vec3{q.x * invSin, q.y * invSin, q.z * invSin} * angle;
    }

    static Quat Slerp(const Quat& a, const Quat& b, float t) {
        Quat qa = a.Normalized();
        Quat qb = b.Normalized();
        float cosHalfTheta = qa.x*qb.x + qa.y*qb.y + qa.z*qb.z + qa.w*qb.w;

        if (cosHalfTheta < 0.f) {
            qb = {-qb.x, -qb.y, -qb.z, -qb.w};
            cosHalfTheta = -cosHalfTheta;
        }
        if (cosHalfTheta > 0.9995f) {
            // Cok yakinlar, linear interpolation + normalize yeterli
            Quat r{
                qa.x + t * (qb.x - qa.x),
                qa.y + t * (qb.y - qa.y),
                qa.z + t * (qb.z - qa.z),
                qa.w + t * (qb.w - qa.w)
            };
            return r.Normalized();
        }
        float halfTheta = std::acos(std::clamp(cosHalfTheta, -1.f, 1.f));
        float sinHalfTheta = std::sin(halfTheta);
        float ra = std::sin((1.f - t) * halfTheta) / sinHalfTheta;
        float rb = std::sin(t * halfTheta) / sinHalfTheta;
        return {
            qa.x * ra + qb.x * rb,
            qa.y * ra + qb.y * rb,
            qa.z * ra + qb.z * rb,
            qa.w * ra + qb.w * rb
        };
    }
};

inline float Clamp(float v, float lo, float hi) { return std::max(lo, std::min(v, hi)); }
inline float Lerp(float a, float b, float t) { return a + (b - a) * t; }

} // namespace rd
