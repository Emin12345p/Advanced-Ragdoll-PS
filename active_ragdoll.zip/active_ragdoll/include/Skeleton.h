#pragma once
// =============================================================================
// Skeleton.h
//
// Karakterin fiziksel iskelet temsili. Her Bone bir rigid body'e karsilik
// gelir (ragdoll fizigi icin) ve ayni zamanda bir animasyon joint'idir.
//
// Tasarim notu: RAGE/Euphoria tarzi sistemlerde her "onemli" kemik
// (pelvis, spine, head, upper/lower arm, upper/lower leg, foot) kendi
// rigid body'sine sahiptir; parmak/yüz gibi ince detaylar fizige dahil
// edilmez, sadece animasyondan gelir. Biz de bu konvansiyonu kullaniyoruz.
// =============================================================================

#include "RagdollMath.h"
#include <vector>
#include <string>
#include <cstdint>

namespace rd {

using BoneIndex = int32_t;
constexpr BoneIndex kInvalidBone = -1;

enum class BoneType : uint8_t {
    Pelvis,     // Root - genelde balance hesaplarinin merkezi referansi
    Spine,
    Chest,
    Head,
    UpperArmL, UpperArmR,
    LowerArmL, LowerArmR,
    HandL, HandR,
    UpperLegL, UpperLegR,
    LowerLegL, LowerLegR,
    FootL, FootR,
    Count
};

// Her kemigin fiziksel ozellikleri. Degerler kg/metre cinsinden,
// ortalama 75kg insan antropometrisine gore yaklasik tahminlerdir.
struct BoneInertialProperties {
    float mass = 1.f;
    Vec3  localInertiaDiag = {0.05f, 0.05f, 0.05f}; // diagonal inertia tensor yaklasimi
};

struct Bone {
    std::string      name;
    BoneType         type = BoneType::Count;
    BoneIndex        parent = kInvalidBone;
    std::vector<BoneIndex> children;

    // Animasyon pose'u (local space, parent'a gore) - animasyon sisteminden gelir
    Vec3  animLocalPos  = Vec3::Zero();
    Quat  animLocalRot  = Quat::Identity();

    // Fizik pose'u (world space) - ragdoll rigid body'den gelir
    Vec3  physWorldPos  = Vec3::Zero();
    Quat  physWorldRot  = Quat::Identity();
    Vec3  physLinearVel  = Vec3::Zero();
    Vec3  physAngularVel = Vec3::Zero();

    // Nihai blend edilmis pose (her frame hesaplanir, render/animasyon sistemine gider)
    Vec3  blendedWorldPos = Vec3::Zero();
    Quat  blendedWorldRot = Quat::Identity();

    BoneInertialProperties inertial;

    // Eklem limitleri (PD controller'in asiri tork uretmesini sinirlamak icin)
    float maxTorque = 200.f; // Newton-metre

    // Bu kemigin "ucu" mu? (el, ayak, bas gibi - balance hesaplarinda onemli)
    bool isExtremity = false;
};

class Skeleton {
public:
    BoneIndex AddBone(const std::string& name, BoneType type, BoneIndex parent,
                       const Vec3& restLocalPos, float mass) {
        Bone b;
        b.name = name;
        b.type = type;
        b.parent = parent;
        b.animLocalPos = restLocalPos;
        b.inertial.mass = mass;
        BoneIndex idx = static_cast<BoneIndex>(bones_.size());
        bones_.push_back(std::move(b));
        if (parent != kInvalidBone) {
            bones_[parent].children.push_back(idx);
        }
        return idx;
    }

    Bone& GetBone(BoneIndex i) { return bones_[i]; }
    const Bone& GetBone(BoneIndex i) const { return bones_[i]; }
    size_t BoneCount() const { return bones_.size(); }

    BoneIndex FindByType(BoneType t) const {
        for (size_t i = 0; i < bones_.size(); ++i)
            if (bones_[i].type == t) return static_cast<BoneIndex>(i);
        return kInvalidBone;
    }

    float TotalMass() const {
        float m = 0.f;
        for (auto& b : bones_) m += b.inertial.mass;
        return m;
    }

    std::vector<Bone>& Bones() { return bones_; }
    const std::vector<Bone>& Bones() const { return bones_; }

private:
    std::vector<Bone> bones_;
};

// Standart insan iskeleti olusturur (75kg referans, gercekci kutle dagilimi).
// Kutle dagilimi kaynagi: biyomekanikte yaygin kullanilan Winter (2009)
// "Biomechanics and Motor Control of Human Movement" antropometrik tablolari,
// basitlestirilmis (segment mass / total body mass oranlari).
inline Skeleton CreateHumanoidSkeleton(float totalMassKg = 75.f) {
    Skeleton sk;
    // Segment mass oranlari (toplam vucut kutlesine oran)
    const float pelvisFrac   = 0.142f;
    const float spineFrac    = 0.16f;
    const float chestFrac    = 0.16f;
    const float headFrac     = 0.081f;
    const float upperArmFrac = 0.028f;
    const float lowerArmFrac = 0.016f;
    const float handFrac     = 0.006f;
    const float upperLegFrac = 0.1f;
    const float lowerLegFrac = 0.0465f;
    const float footFrac     = 0.0145f;

    BoneIndex pelvis = sk.AddBone("pelvis", BoneType::Pelvis, kInvalidBone,
                                   Vec3(0, 1.0f, 0), totalMassKg * pelvisFrac);

    BoneIndex spine = sk.AddBone("spine", BoneType::Spine, pelvis,
                                  Vec3(0, 0.15f, 0), totalMassKg * spineFrac);

    BoneIndex chest = sk.AddBone("chest", BoneType::Chest, spine,
                                  Vec3(0, 0.2f, 0), totalMassKg * chestFrac);

    sk.AddBone("head", BoneType::Head, chest, Vec3(0, 0.25f, 0), totalMassKg * headFrac);

    BoneIndex upperArmL = sk.AddBone("upperArm_L", BoneType::UpperArmL, chest,
                                      Vec3(-0.2f, 0.15f, 0), totalMassKg * upperArmFrac);
    BoneIndex lowerArmL = sk.AddBone("lowerArm_L", BoneType::LowerArmL, upperArmL,
                                      Vec3(0, -0.28f, 0), totalMassKg * lowerArmFrac);
    BoneIndex handL = sk.AddBone("hand_L", BoneType::HandL, lowerArmL,
                                  Vec3(0, -0.25f, 0), totalMassKg * handFrac);
    sk.GetBone(handL).isExtremity = true;

    BoneIndex upperArmR = sk.AddBone("upperArm_R", BoneType::UpperArmR, chest,
                                      Vec3(0.2f, 0.15f, 0), totalMassKg * upperArmFrac);
    BoneIndex lowerArmR = sk.AddBone("lowerArm_R", BoneType::LowerArmR, upperArmR,
                                      Vec3(0, -0.28f, 0), totalMassKg * lowerArmFrac);
    BoneIndex handR = sk.AddBone("hand_R", BoneType::HandR, lowerArmR,
                                  Vec3(0, -0.25f, 0), totalMassKg * handFrac);
    sk.GetBone(handR).isExtremity = true;

    BoneIndex upperLegL = sk.AddBone("upperLeg_L", BoneType::UpperLegL, pelvis,
                                      Vec3(-0.1f, -0.05f, 0), totalMassKg * upperLegFrac);
    BoneIndex lowerLegL = sk.AddBone("lowerLeg_L", BoneType::LowerLegL, upperLegL,
                                      Vec3(0, -0.45f, 0), totalMassKg * lowerLegFrac);
    BoneIndex footL = sk.AddBone("foot_L", BoneType::FootL, lowerLegL,
                                  Vec3(0, -0.42f, 0.05f), totalMassKg * footFrac);
    sk.GetBone(footL).isExtremity = true;

    BoneIndex upperLegR = sk.AddBone("upperLeg_R", BoneType::UpperLegR, pelvis,
                                      Vec3(0.1f, -0.05f, 0), totalMassKg * upperLegFrac);
    BoneIndex lowerLegR = sk.AddBone("lowerLeg_R", BoneType::LowerLegR, upperLegR,
                                      Vec3(0, -0.45f, 0), totalMassKg * lowerLegFrac);
    BoneIndex footR = sk.AddBone("foot_R", BoneType::FootR, lowerLegR,
                                  Vec3(0, -0.42f, 0.05f), totalMassKg * footFrac);
    sk.GetBone(footR).isExtremity = true;

    return sk;
}

} // namespace rd
