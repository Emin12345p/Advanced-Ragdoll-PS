#pragma once
// =============================================================================
// BalanceController.h
//
// Karakterin "ayakta kalma" mantigi. Gercek insan biyomekaniginde, denge
// su sekilde calisir:
//
//   1. Vucudun Center of Mass'ini (COM) hesapla
//   2. COM'u yere izdusur (XZ plane)
//   3. "Support Polygon" (ayaklarin temas noktalarinin olusturdugu alan)
//      ile karsilastir
//   4. Eger COM projeksiyonu support polygon DISINDAYSA -> dengesizlik var,
//      duzeltici aksiyon gerekli:
//        a) "Ankle strategy": ayak bilegi torku ile kucuk duzeltmeler (kucuk hatalar)
//        b) "Hip strategy": govdeyi (pelvis/spine) ters yone egerek COM'u geri cek
//        c) Hata cok buyukse: adim at (foot placement) veya dusmeye birak
//
// Bu sistem (a) ve (b)'yi PD controller uzerinden uygular. (c) - adim atma -
// bu implementasyonda BASITLESTIRILMIS: tam stepping/footstep planner yok,
// ama "recovery failed" durumu tespit edilip disariya sinyal veriliyor,
// boylece ust katman (ActiveRagdollSystem) karakteri dusmeye birakabilir
// veya animasyon sistemine "step" tetikleyebilir.
//
// Bu, RAGE/Euphoria'nin yaptigi tam "dynamic balance" degil (onlarda gercek
// zamanli adim planlama + onlarca davranis var) ama AYNI TEMEL PRENSIP:
// COM-tabanli denge hatasi -> duzeltici tork. Bu, akademik robotik ve oyun
// fizigi literaturunde "Linear Inverted Pendulum Model" (LIPM) tabanli
// denge kontrolculerinin basitlestirilmis bir versiyonudur.
// =============================================================================

#include "RagdollMath.h"
#include "Skeleton.h"
#include <vector>
#include <optional>

namespace rd {

struct SupportPolygon {
    // Basitlestirme: support polygon'u iki ayak noktasi arasinda bir
    // "kapsul/segment + güvenlik marjı" olarak modelliyoruz. Gercek bir
    // convex-hull (cok ayak/el destegi dahil) daha dogru olur ama bu
    // basitlestirme cogu yuruyen/duran karakter durumu icin yeterlidir.
    Vec3 footL_ground;
    Vec3 footR_ground;
    float margin = 0.06f; // ayak tabaninin yaklasik yariciapi (metre)
    bool footLGrounded = false;
    bool footRGrounded = false;

    // Bir noktanin (XZ, world space) support polygon icinde olup olmadigini
    // ve "ne kadar disarida" oldugunu (penetration miktari, negatifse icinde)
    // hesaplar. Donen deger: en yakin polygon noktasina olan vektor (duzeltme
    // yonu) ve disarida-olma mesafesi.
    struct Result {
        bool inside = true;
        float distanceOutside = 0.f; // 0 ise tam sinirda/icinde
        Vec3 correctionDirXZ = Vec3::Zero(); // icine dogru birim vektor (XZ)
    };

    Result Evaluate(const Vec3& pointXZ) const {
        Result r;

        if (!footLGrounded && !footRGrounded) {
            // Hicbir ayak yerde degil (havada/zipliyor) - destek yok.
            r.inside = false;
            r.distanceOutside = 999.f;
            return r;
        }

        if (footLGrounded && !footRGrounded) {
            Vec3 d = pointXZ - footL_ground;
            d.y = 0.f;
            float dist = d.Length();
            r.inside = dist <= margin;
            r.distanceOutside = std::max(0.f, dist - margin);
            r.correctionDirXZ = (dist > 1e-5f) ? (-d).Normalized() : Vec3::Zero();
            return r;
        }
        if (footRGrounded && !footLGrounded) {
            Vec3 d = pointXZ - footR_ground;
            d.y = 0.f;
            float dist = d.Length();
            r.inside = dist <= margin;
            r.distanceOutside = std::max(0.f, dist - margin);
            r.correctionDirXZ = (dist > 1e-5f) ? (-d).Normalized() : Vec3::Zero();
            return r;
        }

        // Iki ayak da yerde: support polygon = iki ayak arasindaki segment
        // (+ margin). Noktanin segmente en yakin projeksiyonunu bul.
        Vec3 a = footL_ground; a.y = 0.f;
        Vec3 b = footR_ground; b.y = 0.f;
        Vec3 p = pointXZ; p.y = 0.f;

        Vec3 ab = b - a;
        float abLenSq = ab.LengthSq();
        float t = (abLenSq > 1e-8f) ? Clamp((p - a).Dot(ab) / abLenSq, 0.f, 1.f) : 0.f;
        Vec3 closest = a + ab * t;

        Vec3 d = p - closest;
        float dist = d.Length();
        r.inside = dist <= margin;
        r.distanceOutside = std::max(0.f, dist - margin);
        r.correctionDirXZ = (dist > 1e-5f) ? (-d).Normalized() : Vec3::Zero();
        return r;
    }
};

struct BalanceState {
    Vec3 centerOfMass = Vec3::Zero();
    Vec3 centerOfMassVelocity = Vec3::Zero();
    SupportPolygon::Result supportResult;

    // 0 = mukemmel dengede, 1 = recovery limitinde, >1 = recovery basarisiz
    // (karakter artik tutamiyor, dusmeli)
    float instabilityRatio = 0.f;

    bool isBalanceCritical = false; // ust katmana "düşme" sinyali
};

class BalanceController {
public:
    // maxRecoverableLean: COM'un support polygon disinda, hala kurtarilabilir
    // sayilan maksimum mesafesi (metre). Bunun ustunde recovery "basarisiz" sayilir.
    explicit BalanceController(float maxRecoverableLean = 0.35f)
        : maxRecoverableLean_(maxRecoverableLean) {}

    // Tum kemiklerin world-space pozisyon/kutlesine gore COM hesapla.
    static Vec3 ComputeCenterOfMass(const Skeleton& sk) {
        Vec3 weightedSum = Vec3::Zero();
        float totalMass = 0.f;
        for (auto& bone : sk.Bones()) {
            weightedSum += bone.physWorldPos * bone.inertial.mass;
            totalMass += bone.inertial.mass;
        }
        if (totalMass < 1e-6f) return Vec3::Zero();
        return weightedSum * (1.f / totalMass);
    }

    // Her frame cagrilir. Skeleton'daki guncel fizik pozlarini okur,
    // denge durumunu hesaplar.
    BalanceState Evaluate(const Skeleton& sk, const SupportPolygon& support,
                           const Vec3& prevCOM, float dt) const {
        BalanceState state;
        state.centerOfMass = ComputeCenterOfMass(sk);
        state.centerOfMassVelocity = (dt > 1e-6f)
            ? (state.centerOfMass - prevCOM) * (1.f / dt)
            : Vec3::Zero();

        // "Capture point" yaklasimi (LIPM-tabanli denge kontrolunde standart):
        // Sadece statik COM pozisyonuna degil, COM'un HIZINA da bakarak nereye
        // gidecegini tahmin ederiz. Hizli hareket eden bir govde, durdugunda
        // daha ileri gidecektir — bu yuzden "etkin nokta" COM + k * velocity'dir.
        const float lookaheadTime = 0.18f; // ampirik, ayarlanabilir
        Vec3 effectivePoint = state.centerOfMass + state.centerOfMassVelocity * lookaheadTime;

        state.supportResult = support.Evaluate(effectivePoint);

        if (state.supportResult.inside) {
            state.instabilityRatio = 0.f;
        } else {
            state.instabilityRatio = state.supportResult.distanceOutside / maxRecoverableLean_;
        }

        state.isBalanceCritical = state.instabilityRatio >= 1.f;
        return state;
    }

    // Govdeye (pelvis/spine/chest) uygulanacak duzeltici "lean" hedefi uretir.
    // Bu, "hip strategy" dedigimiz seyin uygulamasidir: COM disardaysa,
    // govdeyi ters yone egerek COM'u merkeze geri cekmeye calisiriz.
    //
    // Donen deger: ek bir rotasyon (delta quaternion), bu PD controller'in
    // hedef rotasyonuna EKLENIR (compose edilir).
    Quat ComputeHipRecoveryRotation(const BalanceState& state, float maxLeanAngleRad = 0.35f) const {
        if (state.supportResult.inside || state.supportResult.correctionDirXZ.LengthSq() < 1e-8f) {
            return Quat::Identity();
        }

        // correctionDirXZ: "icine dogru" yon. Govdeyi bu yone egmek icin,
        // bu yonun dik kesenine (perpendicular, Y eksenine gore) gore bir
        // rotasyon eksen olustururuz. Egim miktari, instability ratio ile
        // olceklenir (ne kadar disardaysak o kadar fazla egil).
        Vec3 leanDir = state.supportResult.correctionDirXZ;
        Vec3 rotAxis = Vec3::Up().Cross(leanDir).Normalized();
        if (rotAxis.LengthSq() < 1e-8f) return Quat::Identity();

        float leanAmount = Clamp(state.instabilityRatio, 0.f, 1.f) * maxLeanAngleRad;
        return Quat::FromAxisAngle(rotAxis, leanAmount);
    }

private:
    float maxRecoverableLean_;
};

} // namespace rd
