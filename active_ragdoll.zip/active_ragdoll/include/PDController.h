#pragma once
// =============================================================================
// PDController.h
//
// RAGE/Euphoria tarzi "active ragdoll" sistemlerinin temel tasi: her eklem
// icin bir Proportional-Derivative (PD) controller. Mantik basit ama guclu:
//
//   tork = Kp * (hedef_rotasyon - mevcut_rotasyon) - Kd * angular_velocity
//
// Bu, bir "yumusak yay + sonumleyici" gibi davranir: eklem hedef pozuna
// (animasyondan gelen pose) ulasmaya CALISIR ama fizik motoruna tam baglidir.
// Yani bir carpisma/itme oldugunda, controller hedefe geri donmeye calisirken
// gercek fizik etkilesimi (cevredeki nesneler, yercekimi, momentum) devam eder.
//
// Bu yuzden "active" ragdoll denir: pasif ragdoll (sadece yercekimi + collision)
// degil, ama full keyframe animasyon da degil — ikisinin ortasinda, fizige
// gercekten tepki veren ama bir "niyet" (hedef pose) tasiyan bir sistem.
// =============================================================================

#include "RagdollMath.h"

namespace rd {

struct PDGains {
    float kp = 800.f;   // Proportional gain - "ne kadar hizli hedefe gitmeye calis"
    float kd = 60.f;    // Derivative gain - "ne kadar sonumle (titremeyi onle)"

    // Kritik sonumleme (critical damping) yaklasik formulu:
    // Eger sistemi salinimsiz, en hizli sekilde hedefe oturtmak istiyorsan
    // kd ~= 2 * sqrt(kp * efektif_inertia) civarinda olmali.
    // Pratikte oyun fizigi icin bu degeri elle ayarlamak (tuning) gerekir.
    static PDGains CriticalDamping(float kp_, float effectiveInertia) {
        PDGains g;
        g.kp = kp_;
        g.kd = 2.f * std::sqrt(kp_ * effectiveInertia);
        return g;
    }
};

class PDJointController {
public:
    explicit PDJointController(PDGains gains = {}) : gains_(gains) {}

    void SetGains(const PDGains& g) { gains_ = g; }
    const PDGains& Gains() const { return gains_; }

    // Bir eklemin mevcut rotasyonunu, hedef rotasyona yaklastirmak icin
    // gereken torku hesaplar (eklemin local/parent-relative uzayinda).
    //
    // currentRot:      eklemin su anki rotasyonu (fizik simulasyonundan)
    // targetRot:        eklemin hedef rotasyonu (animasyondan)
    // currentAngVel:    eklemin su anki acisal hizi (rad/s)
    // maxTorque:        bu eklemin uretebilecegi maksimum tork (Newton-metre)
    //
    // Donen deger: uygulanacak tork vektoru (world veya parent space,
    // cagiran tarafin hangi uzayda calistigina bagli — tutarli olmasi yeterli)
    Vec3 ComputeTorque(const Quat& currentRot, const Quat& targetRot,
                        const Vec3& currentAngVel, float maxTorque) const {
        // Rotasyon hatasi: targetRot'a gitmek icin gereken "delta rotation"
        // q_error = target * current^-1  =>  axis-angle'a cevirilince
        // "su yonde, bu kadar derece donmen gerekiyor" bilgisini verir.
        Quat error = targetRot * currentRot.Conjugate();
        Vec3 angularError = error.ToAngularError(); // axis * angle (radyan)

        Vec3 torque = angularError * gains_.kp - currentAngVel * gains_.kd;

        // Tork limitleme: gercek kaslar/motorlar sinirsiz guc uretemez.
        // Bu hem realism hem de stabilite icin kritik (limitsiz PD controller
        // patlayici/unstable davranabilir, ozellikle buyuk hata anlarinda).
        float mag = torque.Length();
        if (mag > maxTorque && mag > 1e-6f) {
            torque *= (maxTorque / mag);
        }
        return torque;
    }

private:
    PDGains gains_;
};

} // namespace rd
