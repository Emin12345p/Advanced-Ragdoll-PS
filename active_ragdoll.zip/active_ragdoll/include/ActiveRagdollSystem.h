#pragma once
// =============================================================================
// ActiveRagdollSystem.h
//
// Her seyi birlestiren ust katman. Bir "state machine" olarak calisir:
//
//   ANIMATED -----(hit/impulse)----> RAGDOLL_REACTING
//   RAGDOLL_REACTING -----(denge kurulamadi)----> RAGDOLL_FALLING
//   RAGDOLL_REACTING -----(denge kuruldu, stabil)----> RECOVERING
//   RECOVERING -----(blend tamamlandi)----> ANIMATED
//   RAGDOLL_FALLING -----(yerde durdu, X sure gecti)----> GETTING_UP (opsiyonel,
//                                                          bu impl'de stub)
//
// Bu, NaturalMotion Euphoria'nin ve RAGE'in benzer sistemlerinin (ve genel
// olarak "active ragdoll" / "hit reaction" literaturunun) temel davranis
// desenidir: fizik darbe sonrasi devreye girer, balance controller geri
// kazanmaya calisir, basarili olursa yumusakca animasyona blend edilir.
// =============================================================================

#include "RagdollMath.h"
#include "Skeleton.h"
#include "PDController.h"
#include "BalanceController.h"
#include <unordered_map>
#include <functional>

namespace rd {

enum class RagdollState : uint8_t {
    Animated,         // Tam animasyon, fizik PD controller'lar pasif (referans takip ediyor ama gorunmuyor)
    RagdollReacting,  // Darbe sonrasi, balance controller aktif, kurtarmaya calisiyor
    Recovering,       // Denge kurtarildi, animasyona geri blend ediliyor
    Falling           // Recovery basarisiz, tam pasif ragdoll (yer cekimi + collision only)
};

struct ActiveRagdollConfig {
    // Darbe siddeti bu esigi gecerse Animated -> RagdollReacting tetiklenir
    float impulseThreshold = 4.f; // m/s cinsinden hiz degisimi (delta-v)

    // RagdollReacting durumunda balance kurulduktan sonra ne kadar sure
    // stabil kalmasi gerektigi (Recovering'e gecmeden once) - "gercekten
    // dengeye girdi mi yoksa anlik mi" diye filtrelemek icin.
    float stableTimeToRecover = 0.35f;

    // Recovering durumunun blend suresi (saniye) - ragdoll pozundan
    // animasyon pozuna ne kadar zamanda gecilecek.
    float recoverBlendDuration = 0.5f;

    // PD controller gains, govde bolgesine gore farkli olabilir
    // (govde/pelvis daha "sert" tutulur, kollar daha "gevsek" - gercek
    // insan refleksinde de govde dengeyi korurken kollar daha serbesttir)
    PDGains coreGains   = PDGains::CriticalDamping(1200.f, 0.6f); // pelvis/spine/chest
    PDGains limbGains   = PDGains::CriticalDamping(400.f, 0.3f);  // kol/bacak
    PDGains extremityGains = PDGains::CriticalDamping(150.f, 0.1f); // el/ayak/bas

    float maxRecoverableLean = 0.35f; // metre, BalanceController'a iletilir

    // Govdeye uygulanan duzeltici kuvvetin maksimum ivmesi (m/s^2).
    // Gercek insan kalca/govde refleksinin urettigi yatay duzeltme ivmesi
    // ~1-3g araliginda kabul edilir (g=9.81); buyuk darbelerde bu yetersiz
    // kalir ve karakter dusmeye gecer (bu kasitli — sinirsiz "yapiskan"
    // denge gercekci olmazdi).
    float maxRecoverForceAccel = 18.f;
};

class ActiveRagdollSystem {
public:
    ActiveRagdollSystem(Skeleton& skeleton, const ActiveRagdollConfig& cfg = {})
        : skeleton_(skeleton)
        , config_(cfg)
        , balanceController_(cfg.maxRecoverableLean)
        , prevCOM_(BalanceController::ComputeCenterOfMass(skeleton))
    {
        // Her kemik tipine uygun PD gain'i ata
        for (auto& bone : skeleton_.Bones()) {
            controllers_[&bone] = PDJointController(SelectGainsFor(bone));
        }
    }

    RagdollState State() const { return state_; }
    const BalanceState& LastBalanceState() const { return lastBalanceState_; }

    // Disaridan (carpisma sistemi, mermi vurusu, arac carpmasi vb) cagrilir.
    // impulse: world-space itme vektoru (Newton*saniye, yani momentum degisimi)
    // targetBone: hangi kemige uygulandigi (govde merkezi default)
    void ApplyImpulse(const Vec3& impulse, BoneIndex targetBone = kInvalidBone) {
        if (targetBone == kInvalidBone) {
            targetBone = skeleton_.FindByType(BoneType::Chest);
        }
        Bone& bone = skeleton_.GetBone(targetBone);
        if (bone.inertial.mass > 1e-6f) {
            bone.physLinearVel += impulse * (1.f / bone.inertial.mass);
        }

        float deltaV = impulse.Length() / std::max(bone.inertial.mass, 1e-6f);
        if (deltaV >= config_.impulseThreshold && state_ == RagdollState::Animated) {
            EnterRagdollReacting();
        }
    }

    // Her frame cagrilir. dt: saniye.
    // support: o anki ayak temas bilgisi (fizik/collision sisteminden gelir)
    void Update(float dt, const SupportPolygon& support) {
        switch (state_) {
            case RagdollState::Animated:
                UpdateAnimated(dt);
                break;
            case RagdollState::RagdollReacting:
                UpdateRagdollReacting(dt, support);
                break;
            case RagdollState::Recovering:
                UpdateRecovering(dt, support);
                break;
            case RagdollState::Falling:
                UpdateFalling(dt, support);
                break;
        }

        ComputeBlendedPose();
    }

private:
    PDGains SelectGainsFor(const Bone& bone) const {
        if (bone.isExtremity) return config_.extremityGains;
        switch (bone.type) {
            case BoneType::Pelvis:
            case BoneType::Spine:
            case BoneType::Chest:
                return config_.coreGains;
            default:
                return config_.limbGains;
        }
    }

    void EnterRagdollReacting() {
        state_ = RagdollState::RagdollReacting;
        stableTimer_ = 0.f;
        // Blend agirligini hemen 1.0'a cek (tam fizik gorunsun) - ani gecis
        // gercekci: bir darbe alindiginda govde aninda tepki vermeli, yumusak
        // blend ile degil (yumusak blend sadece TOPARLANIRKEN kullanilir).
        blendWeight_ = 1.f;
    }

    // Balance controller'in uretttigi duzeltme bilgisini, govde kemiklerine
    // (pelvis/spine/chest) GERCEK bir yatay kuvvet olarak uygular. Bu, "hip
    // strategy"nin lineer kismi: COM destek alani disindaysa, govdeyi merkeze
    // geri ceken bir kuvvet uygulanir (gercek insanda bu, kalca/govde
    // kaslarinin urettigi düzeltici kuvvettir).
    //
    // Onceki versiyondaki hata: ComputeHipRecoveryRotation SADECE bir hedef
    // rotasyonu hesapliyordu ama bu hic bir yerde govdenin LINEER hareketini
    // etkilemiyordu — govde rotasyonen "egiliyor" gibi gozukse de, COM yatay
    // kaymasi hic durdurulmuyordu. Bu fonksiyon o eksigi kapatir.
    void ApplyBalanceRecoveryForce(const BalanceState& bs, float dt) {
        if (bs.supportResult.inside) return; // dengedeyken ek kuvvet gerekmiyor

        // Duzeltme yonu (support polygon merkezine dogru, XZ duzleminde)
        Vec3 dir = bs.supportResult.correctionDirXZ;
        if (dir.LengthSq() < 1e-8f) return;

        // Kuvvet siddeti: ne kadar disardaysak o kadar guclu duzelt,
        // ama maxRecoverForceAccel ile sinirla (gercekci kas/refleks limiti).
        float severity = Clamp(bs.instabilityRatio, 0.f, 1.5f); // 1.5'e kadar hala "denenir"
        float accelMagnitude = severity * config_.maxRecoverForceAccel;

        Vec3 correctiveAccel = dir * accelMagnitude;

        // Bu ivmeyi govde kemiklerine uygula (pelvis en agirlikli, cunku
        // gercek insan dengesinde kalca hareketi en buyuk paya sahiptir).
        for (auto& bone : skeleton_.Bones()) {
            float weight = 0.f;
            switch (bone.type) {
                case BoneType::Pelvis: weight = 1.0f; break;
                case BoneType::Spine:  weight = 0.6f; break;
                case BoneType::Chest:  weight = 0.4f; break;
                default: weight = 0.f; break;
            }
            if (weight > 0.f) {
                bone.physLinearVel += correctiveAccel * weight * dt;
            }
        }
    }

    void UpdateAnimated(float dt) {
        blendWeight_ = 0.f;
        // Animasyon durumunda dahi PD controller'lari "golgede" calistirmak
        // faydali olabilir (ornek: ayaklar IK ile yere kilitlenir) ama bu
        // implementasyonda basitlik icin Animated durumunda fizigi pasif
        // tutuyoruz; sadece kinematic pose kopyalaniyor.
        for (auto& bone : skeleton_.Bones()) {
            bone.physWorldPos = TransformToWorld(bone, true);
            bone.physWorldRot = bone.animLocalRot; // basitlestirme: gercekte parent chain ile compose edilir
        }
        prevCOM_ = BalanceController::ComputeCenterOfMass(skeleton_);
        (void)dt;
    }

    void UpdateRagdollReacting(float dt, const SupportPolygon& support) {
        // ONEMLI: Balance degerlendirmesini fizik adimindan ONCE yapiyoruz,
        // ki bu frame'in recovery kuvvetini bu frame'in fizik integrasyonuna
        // uygulayabilelim (bir frame geriden gelen "stale" duzeltme degil).
        BalanceState bs = balanceController_.Evaluate(skeleton_, support, prevCOM_, dt);

        ApplyBalanceRecoveryForce(bs, dt);
        StepPhysicsAndPD(dt, /*pdInfluence=*/1.f, support);

        lastBalanceState_ = bs;
        prevCOM_ = bs.centerOfMass;

        if (bs.isBalanceCritical) {
            // Recovery basarisiz - tam dususe gec
            state_ = RagdollState::Falling;
            stableTimer_ = 0.f;
            return;
        }

        if (bs.supportResult.inside) {
            stableTimer_ += dt;
            if (stableTimer_ >= config_.stableTimeToRecover) {
                state_ = RagdollState::Recovering;
                recoverTimer_ = 0.f;
            }
        } else {
            stableTimer_ = 0.f; // hala dengesiz, sayaci sifirla
        }
    }

    void UpdateRecovering(float dt, const SupportPolygon& support) {
        BalanceState bs = balanceController_.Evaluate(skeleton_, support, prevCOM_, dt);
        ApplyBalanceRecoveryForce(bs, dt);

        // PD etkisini fizikten animasyona kademeli azalt (blend weight 1 -> 0)
        StepPhysicsAndPD(dt, /*pdInfluence=*/1.f, support);

        lastBalanceState_ = bs;
        prevCOM_ = bs.centerOfMass;

        if (bs.isBalanceCritical) {
            // Toparlanirken tekrar dengesini kaybetti - geri ragdoll'a don
            state_ = RagdollState::RagdollReacting;
            stableTimer_ = 0.f;
            return;
        }

        recoverTimer_ += dt;
        float t = Clamp(recoverTimer_ / config_.recoverBlendDuration, 0.f, 1.f);
        blendWeight_ = 1.f - t; // 1 (full ragdoll) -> 0 (full animasyon)

        if (t >= 1.f) {
            state_ = RagdollState::Animated;
            blendWeight_ = 0.f;
        }
    }

    void UpdateFalling(float dt, const SupportPolygon& support) {
        // Tam pasif ragdoll: PD controller etkisi yok (influence=0),
        // sadece yer cekimi + collision (bu ornekte basit integrasyon).
        StepPhysicsAndPD(dt, /*pdInfluence=*/0.f, support);
        blendWeight_ = 1.f;

        // Not: gercek bir sistemde burada "yerde X saniye kaldi -> GettingUp
        // state'ine gec ve get-up animasyonu oynat" mantigi eklenir.
        // Bu, mevcut implementasyonun kasitli olarak disinda tutulan kismi
        // (ayri bir animasyon/IK sistemi gerektirir).
        (void)dt;
    }

    // PD controller'lari calistirip her kemigin acisal hizini/rotasyonunu
    // gunceller. pdInfluence: 0=sadece pasif fizik, 1=tam PD kontrolu.
    //
    // ONEMLI NOT (gercek entegrasyon icin kritik): Bu fonksiyon, izole bir
    // ragdoll alt-sistemini gostermek icin minimal bir integrator kullanir.
    // Gercek ForgeEngine entegrasyonunda bu kisim TAMAMEN SILINMELI ve
    // yerine senin mevcut rigid-body solver'in (sequential impulse + BVH
    // broadphase) kullanilmali. Spesifik olarak eksik olan sey:
    //
    //   - Ayaklarin yere "constraint" ile baglanmasi (contact constraint),
    //     boylece govde havada serbest dusmez, ayak uzerinden zemin
    //     reaksiyon kuvveti tum kinematik zincire yayilir (gercek fizik
    //     motorlarinda bu, constraint solver'in isi).
    //
    // Bu izole test ortaminda gercek bir constraint solver olmadigi icin,
    // asagida BASITLESTIRILMIS bir "virtual support force" uyguluyoruz:
    // yerde olan ayaklarin yukarisindaki TUM zincire (ayni taraftaki bacak +
    // govde) toplam agirligi karsilayacak bir dikey kuvvet dagitiyoruz.
    // Bu, gercek bir fizik motorunun contact constraint'inin YAKLASIK bir
    // tasviri - dogru fizik degil, ama "ayakta dururken yere batmama"
    // davranisini dogru sekilde temsil eder ve PD controller'in govde
    // dengesini test edebilmesini saglar.
    void StepPhysicsAndPD(float dt, float pdInfluence, const SupportPolygon& support) {
        constexpr float kGravity = -9.81f;

        // Toplam destek orani: hic ayak yerde degilse 0 (tam serbest dusus),
        // bir/iki ayak yerdeyse 1 (tam destek). pdInfluence ile carpiliyor
        // ki "Falling" durumunda (pdInfluence=0) destek de devre disi kalsin
        // (karakter gercekten yere yigilsin, ayakta durmaya devam etmesin).
        bool anyGrounded = support.footLGrounded || support.footRGrounded;
        float supportFactor = (anyGrounded ? 1.f : 0.f) * pdInfluence;

        float totalMass = skeleton_.TotalMass();

        for (auto& bone : skeleton_.Bones()) {
            Quat targetRot = bone.animLocalRot; // basitlestirme: world target = anim local
            // (Gercek entegrasyonda animLocalRot parent world rotasyonuyla
            //  compose edilip world-space hedefe cevrilmeli. Burada
            //  okunabilirlik icin tek-seviye basitlestirme yapildi.)

            PDJointController& pd = controllers_.at(&bone);
            Vec3 torque = pd.ComputeTorque(bone.physWorldRot, targetRot,
                                            bone.physAngularVel, bone.maxTorque);
            torque *= pdInfluence;

            // Tork -> acisal ivme (basitlestirilmis skaler inertia, gercekte
            // tensor olmali ama izole test icin diagonal yaklasimi yeterli)
            float effInertia = std::max(bone.inertial.localInertiaDiag.x, 1e-4f);
            Vec3 angularAccel = torque * (1.f / effInertia);

            bone.physAngularVel += angularAccel * dt;
            // Acisal hiz sonumlemesi (numerical damping, stabilite icin)
            bone.physAngularVel *= 0.98f;

            // Acisal hizdan rotasyon guncelle (small-angle integration)
            float angSpeed = bone.physAngularVel.Length();
            if (angSpeed > 1e-6f) {
                Quat delta = Quat::FromAxisAngle(bone.physAngularVel.Normalized(), angSpeed * dt);
                bone.physWorldRot = (delta * bone.physWorldRot).Normalized();
            }

            // --- Linear hareket ---
            // Yercekimi her zaman etkir.
            float gravityAccel = kGravity;

            // Virtual support force: ayaklar yerdeyse, agirligin
            // (yaklasik) karsiligi kadar yukari kuvvet uygula. Bu sayede
            // govde "ayakta duruyor" gibi davranir, serbest dusmez.
            // Not: bu basitlestirme TUM kemiklere esit oranda destek verir;
            // gercek bir kinematik zincirde destek sadece ayaktan govdeye
            // dogru yukselen zincir uzerinden gelir (constraint solver isi).
            float supportAccel = supportFactor * (-gravityAccel); // yercekimini tam dengele

            bone.physLinearVel.y += (gravityAccel + supportAccel) * dt;

            // Hafif lateral sonumleme (havada sallanmayi gercekci kilmak icin,
            // gercek fizikte bu hava direnci + kas sonumlemesinden gelir)
            bone.physLinearVel.x *= 0.995f;
            bone.physLinearVel.z *= 0.995f;

            bone.physWorldPos += bone.physLinearVel * dt;

            // Basit yer collision (y=0 zemin varsayimi, gercek collision
            // sistemiyle degistirilmeli)
            if (bone.physWorldPos.y < 0.f) {
                bone.physWorldPos.y = 0.f;
                bone.physLinearVel.y = std::max(bone.physLinearVel.y, 0.f);
            }
        }
        (void)totalMass; // su an kullanilmiyor, gelecekte orantili dagitim icin ayrildi
    }

    Vec3 TransformToWorld(const Bone& bone, bool /*useAnimPose*/) const {
        // Basitlestirilmis: gercek implementasyonda parent zincirinden
        // world transform compose edilmeli (FK - forward kinematics).
        // Burada izole test amacli, local pos'u direkt donduruyoruz.
        return bone.animLocalPos;
    }

    void ComputeBlendedPose() {
        for (auto& bone : skeleton_.Bones()) {
            // Pozisyon blend: animasyon pos <-> fizik pos
            Vec3 animPos = bone.animLocalPos; // basitlestirme (bkz. not yukarida)
            bone.blendedWorldPos = animPos * (1.f - blendWeight_) + bone.physWorldPos * blendWeight_;

            // Rotasyon blend: Slerp kullanarak (quaternion linear blend YANLIS olur,
            // gimbal/scale sorunlarina yol acar - Slerp dogru yontemdir)
            bone.blendedWorldRot = Quat::Slerp(bone.animLocalRot, bone.physWorldRot, blendWeight_);
        }
    }

    Skeleton& skeleton_;
    ActiveRagdollConfig config_;
    BalanceController balanceController_;

    RagdollState state_ = RagdollState::Animated;
    float blendWeight_ = 0.f; // 0 = full animasyon, 1 = full fizik
    float stableTimer_ = 0.f;
    float recoverTimer_ = 0.f;
    Vec3 prevCOM_;
    BalanceState lastBalanceState_;

    std::unordered_map<Bone*, PDJointController> controllers_;
};

} // namespace rd
